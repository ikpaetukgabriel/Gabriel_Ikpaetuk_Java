package com.company.chatterbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatterbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatterbookApplication.class, args);
	}

}
